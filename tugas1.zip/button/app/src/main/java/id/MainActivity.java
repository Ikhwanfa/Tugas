package id.iroh.pemogramanmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    Button b;
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = (ImageView) findViewById(R.id.thisImage);
        b = (Button) findViewById(R.id.thisButton);

        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                if (flag == 0) {
                    img.setImageResource(R.drawable.donot);
                    flag = 1;
                } else if (flag == 1) {
                    img.setImageResource(R.drawable.play);
                    flag = 0;
                }
            }
        });
    }
}




